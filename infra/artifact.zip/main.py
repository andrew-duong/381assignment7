import boto3
import json

dynamodb_resource = boto3.resource("dynamodb")

table = dynamodb_resource.Table("lotion-30145210")

def delete_handler(event, context):
    id = json.loads(event["id"])
    user = json.loads(id["email"])
    
    try:
        table.delete_item(Key = {
            "email": user,
            "id": id
        })
        return {
            "statusCode": 200,
            "body": "success"
        }
    except Exception as exp:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(exp)})
        }